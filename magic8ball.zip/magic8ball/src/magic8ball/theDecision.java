package magic8ball;

public class theDecision 
{
public static void main(String[] args) 
	{
	shakinTheEightBall();
	}
public static void shakinTheEightBall()
	{
	System.out.println("magic 8 ball... *is racquel gonna leave*");
	rng theRoll = new rng();
	theRoll.shake();
	}

}
	
